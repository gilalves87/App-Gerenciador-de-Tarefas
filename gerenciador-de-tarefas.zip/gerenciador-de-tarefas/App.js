import React, { useState, useEffect, useCallback } from 'react';
import { StyleSheet, Text, View, TextInput, TouchableOpacity, FlatList, Alert } from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import { Ionicons } from '@expo/vector-icons';
import AsyncStorage from '@react-native-async-storage/async-storage';
import Modal from 'react-native-modal';
import { Calendar } from 'react-native-calendars';
import * as Notifications from 'expo-notifications';
import { Picker } from '@react-native-picker/picker';

const Stack = createStackNavigator();

// Funções auxiliares para persistência
const loadTasks = async (userId) => {
  try {
    const storedTasks = await AsyncStorage.getItem(userId);
    return storedTasks ? JSON.parse(storedTasks) : [];
  } catch (error) {
    console.error('Erro ao carregar tarefas', error);
    return [];
  }
};

const saveTasks = async (userId, tasks) => {
  try {
    await AsyncStorage.setItem(userId, JSON.stringify(tasks));
  } catch (error) {
    console.error('Erro ao salvar tarefas', error);
  }
};

// Função para agendar notificação
const scheduleNotification = async (taskText, date) => {
  const schedulingDate = new Date(date); // A data da tarefa

  await Notifications.scheduleNotificationAsync({
    content: {
      title: "Lembrete de Tarefa",
      body: `Você tem que fazer: ${taskText}`,
    },
    trigger: {
      year: schedulingDate.getFullYear(),
      month: schedulingDate.getMonth() + 1, // mês é 0 indexado
      day: schedulingDate.getDate(),
      hour: schedulingDate.getHours(),
      minute: schedulingDate.getMinutes(),
      second: 0,
    },
  });
};

// Tela de Login
function LoginScreen({ navigation, route }) {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [users, setUsers] = useState(route.params?.users || []);
  const [error, setError] = useState('');

  const login = useCallback(() => {
    const user = users.find((u) => u.name === username);
    if (user && password === user.password) {
      navigation.navigate('Home', { activeUser: user });
    } else {
      setError('Nome de usuário ou senha incorretos.');
    }
  }, [users, username, password, navigation]);

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Login</Text>
      <TextInput
        style={styles.input}
        placeholder="Nome de usuário"
        value={username}
        onChangeText={setUsername}
      />
      <TextInput
        style={styles.input}
        placeholder="Senha"
        value={password}
        secureTextEntry={true}
        onChangeText={setPassword}
      />
      {error && <Text style={styles.errorText}>{error}</Text>}
      <TouchableOpacity style={styles.button} onPress={login}>
        <Text style={styles.buttonText}>Entrar</Text>
      </TouchableOpacity>
      <TouchableOpacity onPress={() => navigation.navigate('User', { setUsers })}>
        <Text style={styles.userButton}>Criar Novo Usuário</Text>
      </TouchableOpacity>
    </View>
  );
}

// Tela principal para Gerenciamento de Tarefas
function HomeScreen({ navigation, route }) {
  const [task, setTask] = useState('');
  const [tasks, setTasks] = useState([]);
  const [note, setNote] = useState('');
  const [selectedDate, setSelectedDate] = useState('');
  const [editedTask, setEditedTask] = useState(null);
  const [priority, setPriority] = useState('Média'); // Prioridade
  const [isModalVisible, setIsModalVisible] = useState(false); // Controla a visibilidade do modal
  const { activeUser } = route.params;

  // Carregar tarefas quando o usuário é selecionado
  useEffect(() => {
    if (activeUser) {
      loadTasks(activeUser.id).then(setTasks);
    }
  }, [activeUser]);

  // Função para adicionar ou editar a tarefa
  const addOrEditTask = useCallback(() => {
    if (task.trim() === '' || selectedDate === '') return;

    let updatedTasks;
    if (editedTask) {
      updatedTasks = tasks.map((t) =>
        t.id === editedTask.id ? { ...t, text: task, note, date: selectedDate, priority } : t
      );
    } else {
      const newTask = { id: Date.now().toString(), text: task, note, date: selectedDate, priority };
      updatedTasks = [...tasks, newTask];
      scheduleNotification(task, selectedDate); // Agendar notificação ao adicionar a tarefa
    }

    setTasks(updatedTasks);
    saveTasks(activeUser.id, updatedTasks);

    setTask('');
    setNote('');
    setSelectedDate('');
    setPriority('Média'); // Resetar a prioridade
    setEditedTask(null);
  }, [task, note, selectedDate, priority, editedTask, tasks, activeUser.id]);

  // Remover tarefa
  const removeTask = useCallback((taskId) => {
    const updatedTasks = tasks.filter((item) => item.id !== taskId);
    setTasks(updatedTasks);
    saveTasks(activeUser.id, updatedTasks);
  }, [tasks, activeUser.id]);

  // Editar tarefa
  const editTask = useCallback((task) => {
    setTask(task.text);
    setNote(task.note);
    setSelectedDate(task.date);
    setPriority(task.priority); // Carregar prioridade da tarefa
    setEditedTask(task);
  }, []);

  // Mostrar/Fechar Modal
  const toggleModal = useCallback(() => {
    setIsModalVisible(!isModalVisible);
  }, [isModalVisible]);

  // Ordenação das tarefas pela prioridade
  const sortedTasks = tasks.sort((a, b) => {
    const priorityOrder = { Alta: 1, Média: 2, Baixa: 3 };
    return priorityOrder[a.priority] - priorityOrder[b.priority];
  });

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Gerenciador de Tarefas</Text>
      {activeUser ? (
        <>
          <Text style={styles.subtitle}>Usuário Ativo: {activeUser.name}</Text>
          <TextInput
            style={styles.input}
            placeholder="Digite uma nova tarefa"
            value={task}
            onChangeText={setTask}
          />
          <TextInput
            style={styles.input}
            placeholder="Adicione uma observação"
            value={note}
            onChangeText={setNote}
          />

          {/* Seletor de Prioridade */}
          <View style={styles.priorityContainer}>
            <Text>Prioridade</Text>
            <Picker
              selectedValue={priority}
              onValueChange={(itemValue) => setPriority(itemValue)}
            >
              <Picker.Item label="Alta" value="Alta" />
              <Picker.Item label="Média" value="Média" />
              <Picker.Item label="Baixa" value="Baixa" />
            </Picker>
          </View>

          <TouchableOpacity onPress={toggleModal} style={styles.calendarIconContainer}>
            <Ionicons name="calendar" size={32} color="blue" />
          </TouchableOpacity>

          <TouchableOpacity style={styles.button} onPress={addOrEditTask}>
            <Text style={styles.buttonText}>
              {editedTask ? 'Editar Tarefa' : 'Adicionar Tarefa'}
            </Text>
          </TouchableOpacity>

          <FlatList
            data={sortedTasks}
            keyExtractor={(item) => item.id}
            renderItem={({ item }) => (
              <View style={styles.taskContainer}>
                <Text style={styles.taskText}>{item.text}</Text>
                <Text style={styles.noteText}>Obs: {item.note}</Text>
                <Text style={styles.dateText}>Data: {item.date}</Text>
                <Text style={styles.priorityText}>Prioridade: {item.priority}</Text>
                <TouchableOpacity onPress={() => editTask(item)}>
                  <Text style={styles.editText}>Editar</Text>
                </TouchableOpacity>
                <TouchableOpacity onPress={() => removeTask(item.id)}>
                  <Text style={styles.removeText}>Remover</Text>
                </TouchableOpacity>
              </View>
            )}
          />
        </>
      ) : (
        <Text style={styles.subtitle}>Nenhum usuário ativo selecionado</Text>
      )}

      {/* Modal com o Calendário */}
      <Modal isVisible={isModalVisible} onBackdropPress={toggleModal}>
        <View style={styles.modalContainer}>
          <Calendar
            onDayPress={(day) => {
              setSelectedDate(day.dateString);
              toggleModal(); // Fechar o modal após selecionar a data
            }}
            markedDates={{
              [selectedDate]: { selected: true, selectedColor: 'blue' },
            }}
          />
        </View>
      </Modal>
    </View>
  );
}

// Tela para criar novo usuário
function UserScreen({ navigation, route }) {
  const [newUsername, setNewUsername] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [users, setUsers] = useState(route.params?.users || []);

  const createUser = () => {
    if (newUsername.trim() && newPassword.trim()) {
      const newUser = { id: Date.now().toString(), name: newUsername, password: newPassword };
      const updatedUsers = [...users, newUser];
      setUsers(updatedUsers);
      route.params.setUsers(updatedUsers); // Atualiza os usuários no login
      navigation.goBack();
    } else {
      alert('Nome de usuário e senha são obrigatórios.');
    }
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Criar Novo Usuário</Text>
      <TextInput
        style={styles.input}
        placeholder="Nome de usuário"
        value={newUsername}
        onChangeText={setNewUsername}
      />
      <TextInput
        style={styles.input}
        placeholder="Senha"
        secureTextEntry
        value={newPassword}
        onChangeText={setNewPassword}
      />
      <TouchableOpacity style={styles.button} onPress={createUser}>
        <Text style={styles.buttonText}>Criar Usuário</Text>
      </TouchableOpacity>
    </View>
  );
}

export default function App() {
  const [users, setUsers] = useState([]);
  return (
    <NavigationContainer>
      <Stack.Navigator initialRouteName="Login">
        <Stack.Screen name="Login" component={LoginScreen} initialParams={{ users }} />
        <Stack.Screen name="Home" component={HomeScreen} />
        <Stack.Screen name="User" component={UserScreen} initialParams={{ users, setUsers }} />
      </Stack.Navigator>
    </NavigationContainer>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 20,
    textAlign: 'center',
  },
  subtitle: {
    fontSize: 18,
    fontWeight: '600',
    marginBottom: 20,
    textAlign: 'center',
  },
  input: {
    borderColor: '#ddd',
    borderWidth: 1,
    padding: 10,
    marginBottom: 10,
    borderRadius: 5,
    width: '100%',
  },
  button: {
    backgroundColor: '#5cb85c',
    padding: 10,
    borderRadius: 5,
    alignItems: 'center',
    marginBottom: 20,
    width: '100%',
  },
  buttonText: {
    color: '#fff',
    fontSize: 16,
  },
  taskContainer: {
    flexDirection: 'column',
    padding: 10,
    borderBottomWidth: 1,
    borderBottomColor: '#ddd',
    marginBottom: 20,
    width: '100%',
  },
  taskText: {
    fontSize: 16,
    marginBottom: 5,
  },
  noteText: {
    fontSize: 14,
    color: '#555',
    marginBottom: 5,
  },
  dateText: {
    fontSize: 14,
    color: '#777',
    marginBottom: 10,
  },
  priorityText: {
    fontSize: 14,
    color: '#333',
    marginBottom: 5,
  },
  editText: {
    color: 'blue',
    marginBottom: 5,
  },
  removeText: {
    color: '#d9534f',
    fontWeight: 'bold',
  },
  calendarIconContainer: {
    flexDirection: 'row',
    justifyContent: 'center',
    marginTop: 20,
  },
  modalContainer: {
    backgroundColor: 'white',
    padding: 20,
    borderRadius: 10,
  },
  priorityContainer: {
    marginVertical: 10,
    width: '100%',
  },
  errorText: {
    color: 'red',
    marginBottom: 10,
    textAlign: 'center',
  },
  userButton: {
    color: 'blue',
    fontSize: 16,
  },
});
